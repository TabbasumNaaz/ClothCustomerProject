package com.deloitte.carms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.carms.entity.Cloth;
import com.deloitte.carms.repo.ClothRepository;


@Service
public class ClothServiceImpl implements ColthService {
	
	@Autowired
	ClothRepository clothRepository;
	

	@Override
	public List<Cloth> getCars() {
		return clothRepository.findAll();
	}


	@Override
	public List<Cloth> getCar(Integer id) {
		// TODO Auto-generated method stub
		return clothRepository.findByCid(id);
	}

	

}
