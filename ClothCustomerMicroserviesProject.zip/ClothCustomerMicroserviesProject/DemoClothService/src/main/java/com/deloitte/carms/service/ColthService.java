package com.deloitte.carms.service;

import java.util.List;

import com.deloitte.carms.entity.Cloth;

public interface ColthService {
	
	public List<Cloth> getCars();
	public List<Cloth> getCar(Integer id);
	

}
