package com.deloitte.carms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoClothServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoClothServiceApplication.class, args);
	}

}
