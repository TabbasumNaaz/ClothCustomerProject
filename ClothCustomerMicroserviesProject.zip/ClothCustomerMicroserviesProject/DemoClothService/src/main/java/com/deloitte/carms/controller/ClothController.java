package com.deloitte.carms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.carms.entity.Cloth;
import com.deloitte.carms.service.ClothServiceImpl;

@RestController
@RequestMapping("/cloth")
public class ClothController {
	
	@Autowired
	ClothServiceImpl clothServiceImpl;
	
	@GetMapping("/getCloths")
	public ResponseEntity<List<Cloth>> getAllCars()
	{
		List<Cloth> cloth = clothServiceImpl.getCars();
		return new ResponseEntity<List<Cloth>>(cloth, HttpStatus.OK);
	}
	
	@GetMapping("/getCloth/{cid}")
	public ResponseEntity<List<Cloth>> getCarbyCId(@PathVariable("cid") Integer id){
		List<Cloth> cloth = clothServiceImpl.getCar(id);
		return new ResponseEntity<List<Cloth>>(cloth, HttpStatus.OK);
		
	}
	

}
