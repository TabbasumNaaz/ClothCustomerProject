package com.deloitte.carms.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="cloth")
public class Cloth {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer Srno;
	private String color;
	private String brand;
	private String type;
	private Integer cid;
	public Integer getSrno() {
		return Srno;
	}
	public void setSrno(Integer srno) {
		Srno = srno;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public Cloth(Integer srno, String color, String brand, String type, Integer cid) {
		super();
		Srno = srno;
		this.color = color;
		this.brand = brand;
		this.type = type;
		this.cid = cid;
	}
	public Cloth() {
		
	}
	
	
}
