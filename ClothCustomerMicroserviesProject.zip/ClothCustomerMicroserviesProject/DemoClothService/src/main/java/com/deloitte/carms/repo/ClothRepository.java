package com.deloitte.carms.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.carms.entity.Cloth;


public interface ClothRepository extends JpaRepository<Cloth, Integer> {
	
	public List<Cloth> findByCid(Integer custId);
	
	
	

}
