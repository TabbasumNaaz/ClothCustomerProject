package com.deloitte.carms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoClothServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
