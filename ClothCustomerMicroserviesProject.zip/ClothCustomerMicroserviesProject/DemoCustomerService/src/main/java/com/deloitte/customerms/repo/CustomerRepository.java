package com.deloitte.customerms.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.customerms.entity.Customer;



public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	
		public List<Customer> findByCid(Integer custId);

}
