package com.deloitte.customerms.model;

import java.util.List;

import com.deloitte.customerms.entity.Customer;

public class Response
{
	private List<Customer> customerResponse;
	private List<Cloth> clothResponse;
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Response(List<Customer> customerResponse, List<Cloth> clothResponse) {
		super();
		this.customerResponse = customerResponse;
		this.clothResponse = clothResponse;
	}
	public List<Customer> getCustomerResponse() {
		return customerResponse;
	}
	public void setCustomerResponse(List<Customer> customerResponse) {
		this.customerResponse = customerResponse;
	}
	public List<Cloth> getClothResponse() {
		return clothResponse;
	}
	public void setVehicleResponse(List<Cloth> clothResponse) {
		this.clothResponse = clothResponse;
	}
	
	
}
