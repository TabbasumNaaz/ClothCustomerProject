package com.deloitte.customerms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.customerms.entity.Customer;
import com.deloitte.customerms.repo.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public List<Customer> getCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public List<Customer> getCustomer(Integer id) {
		return customerRepository.findByCid(id);
	}

}
